# Terraform Data Engineering Project

Este reposit�rio cont�m um exemplo pr�tico de uso do Terraform na Engenharia de Dados.